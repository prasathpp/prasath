file = open("my_file.txt")
contents = file.read()
print(contents)
