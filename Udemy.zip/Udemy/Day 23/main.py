import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

player = Player()
cars = CarManager()
score = Scoreboard()

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("white")
screen.tracer(0)

game_is_on = True
level = 5
i = 1
timer = 0.1

while game_is_on:
    time.sleep(timer)
    screen.update()
    player.move_forward()
    # speed of cars
    if i % level == 0:
        cars.create_cars()
    cars.move_forward()
    # level change
    if player.ycor() >= 280:
        player.next_level()
        cars.next_level()
        score.update_score()
        i = 1
        level -= 1
        timer *= 0.8
    # collusion of cars
    for car in cars.all_cars:
        if player.distance(car) < 20:
            game_is_on = False
            score.game_over()
    if level < 1:
        game_is_on = False
        score.you_win()

    i += 1

    


    



screen.exitonclick()
