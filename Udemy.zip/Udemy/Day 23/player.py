from turtle import Turtle, Screen

STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280

screen = Screen()
screen.setup(width=600, height=600)

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.setheading(90)
        self.penup()
        self.shape("turtle")
        self.goto(STARTING_POSITION)
    
    def move(self):
        self.forward(MOVE_DISTANCE)
    
    def move_forward(self):
        screen.listen()
        screen.onkeypress(self.move, "Up")

    def next_level(self):
        self.goto(STARTING_POSITION)
    