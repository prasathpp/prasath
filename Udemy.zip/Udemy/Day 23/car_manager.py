from turtle import Turtle, Screen
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager():
    def __init__(self):
        self.not_out = True
        self.all_cars = []
        self.move_distance = STARTING_MOVE_DISTANCE
    
    def create_cars(self):
        new_car = Turtle()
        self.all_cars.append(new_car)
        # new_car.speed()
        new_car.shape("square")
        new_car.penup()
        new_car.setheading(180)
        new_car.color(random.choice(COLORS))
        new_car.shapesize(1,2)
        new_car.goto(320, random.randint(-250,270))
    
    def move_forward(self):
        for cars in self.all_cars:
            cars.forward(self.move_distance)
        
    def next_level(self):
        self.move_distance += MOVE_INCREMENT

