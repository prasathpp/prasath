from turtle import Turtle, Screen

FONT = ("Courier", 24, "bold")


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.goto(-260, 250)
        self.score = 1
        self.display_score()
    
    def display_score(self):
        self.clear()
        self.write(f"Level: {self.score}",font=FONT)

    def update_score(self):
        self.score += 1
        self.display_score()
    
    def game_over(self):
        self.goto(-60,0)
        self.write("Game Over", font=("Courier", 20, "bold"))
    
    def you_win(self):
        self.goto(-60,0)
        self.write("You Win", font=("Courier", 20, "bold"))

