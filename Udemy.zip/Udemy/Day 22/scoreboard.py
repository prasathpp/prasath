from turtle import Turtle, Screen

class ScoreBoard(Turtle):
    pass