print(5)
